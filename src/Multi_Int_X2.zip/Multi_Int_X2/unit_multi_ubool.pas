UNIT Unit_Multi_UBool;
{$MODE OBJFPC}
{$MODESWITCH ADVANCEDRECORDS}
{$LONGSTRINGS ON}
{$MODESWITCH NESTEDCOMMENTS+}

INTERFACE

type

Multi_UBool_Values		= 	(Multi_UBool_UNDEF,Multi_UBool_FALSE,Multi_UBool_TRUE,Multi_UBool_UNDECIDED);

T_Multi_UBool	=	record
					private
						B_Value		:Multi_UBool_Values;
					public
						procedure	Init(v:Multi_UBool_Values); {$ifdef inline_functions_level_1} inline; {$endif}
						function	ToStr:string; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator :=(v:boolean):T_Multi_UBool; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator :=(v:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator :=(v:Multi_UBool_Values):T_Multi_UBool; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator :=(v:T_Multi_UBool):Multi_UBool_Values; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator =(v1,v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator <>(v1,v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator <=(v1,v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator <(v1,v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator >=(v1,v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator >(v1,v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator or(v1,v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator or(v1:T_Multi_UBool;v2:Boolean):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator or(v1:Boolean; v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator and(v1,v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator and(v1:T_Multi_UBool;v2:Boolean):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator and(v1:Boolean; v2:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator not(v1:T_Multi_UBool):Boolean; {$ifdef inline_functions_level_1} inline; {$endif}
						class operator not(v1:T_Multi_UBool):T_Multi_UBool; {$ifdef inline_functions_level_1} inline; {$endif}

					end;

IMPLEMENTATION

(******************************************)
procedure	T_Multi_UBool.Init(v:Multi_UBool_Values);
begin
if (v = Multi_UBool_TRUE) then B_Value:= Multi_UBool_TRUE
else if (v = Multi_UBool_FALSE) then B_Value:= Multi_UBool_FALSE
else B_Value:= Multi_UBool_UNDEF;
end;

function	T_Multi_UBool.ToStr:string;
begin
if (B_Value = Multi_UBool_TRUE) then Result:= 'TRUE'
else if (B_Value = Multi_UBool_FALSE) then Result:= 'FALSE'
else Result:= 'UNDEFINED';
end;

class operator T_Multi_UBool.:=(v:Multi_UBool_Values):T_Multi_UBool;
begin
Result.B_Value:= v;
end;

class operator T_Multi_UBool.:=(v:T_Multi_UBool):Multi_UBool_Values;
begin
Result:= v.B_Value;
end;

class operator T_Multi_UBool.:=(v:Boolean):T_Multi_UBool;
begin
if v then Result.B_Value:= Multi_UBool_TRUE
else Result.B_Value:= Multi_UBool_FALSE;
end;

class operator T_Multi_UBool.:=(v:T_Multi_UBool):Boolean;
begin
if (v.B_Value = Multi_UBool_TRUE) then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.=(v1,v2:T_Multi_UBool):Boolean;
begin
if (v1.B_Value = v2.B_Value) then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.<>(v1,v2:T_Multi_UBool):Boolean;
begin
if (v1.B_Value <> v2.B_Value) then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.<=(v1,v2:T_Multi_UBool):Boolean;
begin
if (v1.B_Value <= v2.B_Value) then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.<(v1,v2:T_Multi_UBool):Boolean;
begin
if (v1.B_Value < v2.B_Value) then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.>=(v1,v2:T_Multi_UBool):Boolean;
begin
if (v1.B_Value >= v2.B_Value) then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.>(v1,v2:T_Multi_UBool):Boolean;
begin
if (v1.B_Value > v2.B_Value) then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.or(v1,v2:T_Multi_UBool):Boolean;
begin
if	(v1.B_Value = Multi_UBool_TRUE)
or	(v2.B_Value = Multi_UBool_TRUE)
then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.or(v1:T_Multi_UBool;v2:Boolean):Boolean;
begin
if	(v1.B_Value = Multi_UBool_TRUE)
or	(v2)
then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.or(v1:Boolean;v2:T_Multi_UBool):Boolean;
begin
if	(v1)
or	(v2.B_Value = Multi_UBool_TRUE)
then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.and(v1,v2:T_Multi_UBool):Boolean;
begin
if	(v1.B_Value = Multi_UBool_TRUE)
and	(v2.B_Value = Multi_UBool_TRUE)
then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.and(v1:T_Multi_UBool;v2:Boolean):Boolean;
begin
if	(v1.B_Value = Multi_UBool_TRUE)
and	(v2)
then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.and(v1:Boolean; v2:T_Multi_UBool):Boolean;
begin
if	(v1)
and	(v2.B_Value = Multi_UBool_TRUE)
then Result:= TRUE
else Result:= FALSE;
end;

class operator T_Multi_UBool.not(v1:T_Multi_UBool):Boolean;
begin
if	(v1.B_Value = Multi_UBool_TRUE) then Result:= FALSE
else Result:= TRUE;
end;

class operator T_Multi_UBool.not(v1:T_Multi_UBool):T_Multi_UBool;
begin
if	(v1.B_Value = Multi_UBool_TRUE) then Result:= Multi_UBool_FALSE
else if (v1.B_Value = Multi_UBool_FALSE) then Result:= Multi_UBool_TRUE
else Result:= Multi_UBool_UNDEF;
end;

begin
end.

