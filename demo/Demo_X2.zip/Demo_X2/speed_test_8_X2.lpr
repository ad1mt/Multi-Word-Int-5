// {$MODE DELPHI}
{$MODESWITCH NESTEDCOMMENTS+}

program speed_test_8_X2;
uses	sysutils
,		strutils
,		strings
,		math
,		Unit_Multi_Int_X2
;

const
MULTI_INT_XV_SIZE	= 32;

M3_SQRT_ITERATIONS	= 500000;
M2_DIV_ITERATIONS	= 1000000;
M2_MUL_ITERATIONS	= 10000000;
M2_SUB_ITERATIONS	= 10000000;

var
i,
start_time,
end_time		:int32;
delta			:double;


(********************************)
procedure test_Multi_Int_X2;
var
MV_i,
MV_j,
MV_k	:Multi_Int_X2;

begin

start_time:= GetTickCount64;

MV_i:= Multi_Int_X2_MAXINT;
MV_i:= (MV_i >> 1);
MV_i:= MV_i + 1;

MV_j:= Multi_Int_X2_MAXINT;
MV_j:= (MV_j >> 5);
MV_j:= MV_j - 5;

i:=0;
while (i < (M2_SUB_ITERATIONS div 2)) do
	begin
	MV_k:= MV_i + MV_j;
	Dec(MV_i);
	Dec(MV_j);
	MV_k:= MV_i + MV_j;
	Inc(MV_i);
	Inc(MV_j);

	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of add with %d bit integers', [delta,M2_SUB_ITERATIONS,(Multi_X2_size * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)
start_time:= GetTickCount64;

MV_i:= Multi_Int_X2_MAXINT;
MV_i:= (MV_i >> 1);
MV_i:= MV_i + 1;

MV_j:= Multi_Int_X2_MAXINT;
MV_j:= (MV_j >> 5);
MV_j:= MV_j - 5;

i:=0;
while (i < (M2_SUB_ITERATIONS div 2)) do
	begin
	MV_k:= MV_i - MV_j;
	Dec(MV_i);
	Dec(MV_j);
	MV_k:= MV_i - MV_j;
	Inc(MV_i);
	Inc(MV_j);

	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of subtract with %d bit integers', [delta,M2_SUB_ITERATIONS,(Multi_X2_size * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

MV_i:= Multi_Int_X2_MAXINT;
MV_j:= 4294967296;
MV_i:= MV_i div MV_j;

start_time:= GetTickCount64;

i:=0;
while (i < M2_MUL_ITERATIONS) do
	begin
	MV_k:= MV_i * MV_j;
	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of multiply with %d bit integers', [delta,M2_MUL_ITERATIONS,(Multi_X2_size * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

start_time:= GetTickCount64;

MV_i:= Multi_Int_X2_MAXINT;
MV_j:= 4294967296;

i:=0;
while (i < (M2_DIV_ITERATIONS div 2)) do
	begin
	MV_k:= MV_i div MV_j;
	Multi_Int_Reset_X2_Last_Divisor;
	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of divide with %d bit integers', [delta,M2_DIV_ITERATIONS,(Multi_X2_size * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)
writeln;
end;


(********************************)
procedure test_Multi_Int_X2_v1;
var
M2_i,
M2_j,
M2_k	:Multi_Int_X2;

begin
start_time:= GetTickCount64;

M2_i:= Multi_Int_X2_MAXINT;
M2_j:= 4294967296;

i:=0;
while (i < (M2_DIV_ITERATIONS div 2)) do
	begin
	M2_k:= M2_i div M2_j;
	Dec(M2_i);
	Dec(M2_j);
	M2_k:= M2_i div M2_j;
	Inc(M2_i);
	Inc(M2_j);

	Inc(i)
	end;

if	M2_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of divide with %d bit integers',[delta,M2_DIV_ITERATIONS,(Multi_X2_size * sizeof(MULTI_INT_1W_U) * 8) ]));

// writeln('sizeof(MULTI_INT_1W_U) = ',sizeof(MULTI_INT_1W_U));
// writeln('Multi_X2_size = ',Multi_X2_size);

(*----*)

start_time:= GetTickCount64;

M2_i:= (Multi_Int_X2_MAXINT >> (((Multi_X2_size * 1) div 4) * MULTI_INT_1W_SIZE));
M2_j:= (Multi_Int_X2_MAXINT >> (((Multi_X2_size * 3) div 4) * MULTI_INT_1W_SIZE));

i:=0;
while (i < (M2_MUL_ITERATIONS div 2)) do
	begin
	M2_k:= M2_i * M2_j;
	Dec(M2_i);
	Dec(M2_j);
	M2_k:= M2_i * M2_j;
	Inc(M2_i);
	Inc(M2_j);

	Inc(i)
	end;

if	M2_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of multiply with %d bit integers', [delta,M2_MUL_ITERATIONS,(Multi_X2_size * sizeof(MULTI_INT_1W_U) * 8)]));


(*----*)

start_time:= GetTickCount64;

M2_i:= (Multi_Int_X2_MAXINT shr 5);
// ShiftDown(M2_i, 5);
M2_i:= M2_i + 5;

M2_j:= (Multi_Int_X2_MAXINT >> 5);
// ShiftDown(M2_j, 11);
M2_j:= M2_j - 11;

i:=0;
while (i < (M2_SUB_ITERATIONS div 2)) do
	begin
	M2_k:= M2_i + M2_j;
	Dec(M2_i);
	Dec(M2_j);
	M2_k:= M2_i + M2_j;
	Inc(M2_i);
	Inc(M2_j);

	Inc(i)
	end;

if	M2_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of add with %d bit integers', [delta,M2_SUB_ITERATIONS,(Multi_X2_size * sizeof(MULTI_INT_1W_U) * 8)]));
(*----*)

start_time:= GetTickCount64;

M2_i:= (Multi_Int_X2_MAXINT shr 5);
// ShiftDown(M2_i, 5);
M2_i:= M2_i + 5;

M2_j:= (Multi_Int_X2_MAXINT >> 5);
// ShiftDown(M2_j, 11);
M2_j:= M2_j - 11;

i:=0;
while (i < (M2_SUB_ITERATIONS div 2)) do
	begin
	M2_k:= M2_i - M2_j;
	Dec(M2_i);
	Dec(M2_j);
	M2_k:= M2_i - M2_j;
	Inc(M2_i);
	Inc(M2_j);

	Inc(i)
	end;

if	M2_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of subtract with %d bit integers', [delta,M2_SUB_ITERATIONS,(Multi_X2_size * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

writeln;
end;

begin
test_Multi_Int_X2;
end.


