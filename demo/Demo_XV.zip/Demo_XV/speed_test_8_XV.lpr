{$MODE OBJFPC}
{$MODESWITCH NESTEDCOMMENTS+}

program speed_test_8_XV;
uses	sysutils
,		strutils
,		strings
,		math
,		Unit_Multi_Int_XV
;

const
MULTI_INT_XV_SIZE	= 256;

M2_DIV_ITERATIONS	= 100000;
M2_MUL_ITERATIONS	= 1000000;
M2_SUB_ITERATIONS	= 1000000;

M3_DIV_ITERATIONS	= 100000;
M3_MUL_ITERATIONS	= 1000000;
M3_SUB_ITERATIONS	= 1000000;

M4_DIV_ITERATIONS	= 100000;
M4_MUL_ITERATIONS	= 1000000;
M4_SUB_ITERATIONS	= 1000000;

MV_SQRT_ITERATIONS	= 100;
MV_DIV_ITERATIONS	= 500;
MV_MUL_ITERATIONS	= 100000;
MV_SUB_ITERATIONS	= 100000;

var
i,
start_time,
end_time		:int32;
delta			:double;


(********************************)
procedure test_Multi_Int_XV;
var
MV_i,
MV_j,
MV_k	:Multi_Int_XV;

begin

start_time:= GetTickCount64;

MV_i:= Multi_Int_XV_MAXINT;
MV_i:= (MV_i >> 1);
MV_i:= MV_i + 1;

MV_j:= Multi_Int_XV_MAXINT;
MV_j:= (MV_j >> 5);
MV_j:= MV_j - 5;

i:=0;
while (i < (MV_SUB_ITERATIONS div 2)) do
	begin
	MV_k:= MV_i + MV_j;
	Dec(MV_i);
	Dec(MV_j);
	MV_k:= MV_i + MV_j;
	Inc(MV_i);
	Inc(MV_j);

	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of add with %d bit integers', [delta,MV_SUB_ITERATIONS,(MULTI_INT_XV_SIZE * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)
start_time:= GetTickCount64;

MV_i:= Multi_Int_XV_MAXINT;
MV_i:= (MV_i >> 1);
MV_i:= MV_i + 1;

MV_j:= Multi_Int_XV_MAXINT;
MV_j:= (MV_j >> 5);
MV_j:= MV_j - 5;

i:=0;
while (i < (MV_SUB_ITERATIONS div 2)) do
	begin
	MV_k:= MV_i - MV_j;
	Dec(MV_i);
	Dec(MV_j);
	MV_k:= MV_i - MV_j;
	Inc(MV_i);
	Inc(MV_j);

	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of subtract with %d bit integers', [delta,MV_SUB_ITERATIONS,(MULTI_INT_XV_SIZE * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

MV_i:= Multi_Int_XV_MAXINT;
MV_j:= 4294967296;
MV_i:= MV_i div MV_j;

start_time:= GetTickCount64;

i:=0;
while (i < MV_MUL_ITERATIONS) do
	begin
	MV_k:= MV_i * MV_j;
	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of multiply with %d bit integers', [delta,MV_MUL_ITERATIONS,(MULTI_INT_XV_SIZE * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

start_time:= GetTickCount64;

MV_i:= Multi_Int_XV_MAXINT;
MV_j:= 4294967296;

i:=0;
while (i < MV_DIV_ITERATIONS) do
	begin
	MV_k:= MV_i div MV_j;
	Multi_Int_Reset_XV_Last_Divisor;
	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of divide with %d bit integers', [delta,MV_DIV_ITERATIONS,(MULTI_INT_XV_SIZE * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

start_time:= GetTickCount64;

MV_i:= Multi_Int_XV_MAXINT;
MV_j:= 4294967296;

i:=0;
while (i < MV_SQRT_ITERATIONS) do
	begin
	MV_k:= sqrt(MV_i);
	Multi_Int_Reset_XV_Last_Divisor;
	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of sqrt with %d bit integers', [delta,MV_SQRT_ITERATIONS,(MULTI_INT_XV_SIZE * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)
writeln;
end;


begin
Multi_Int_Initialisation(MULTI_INT_XV_SIZE);
test_Multi_Int_XV;
end.


