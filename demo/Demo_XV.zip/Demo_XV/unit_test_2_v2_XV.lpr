{$MODE OBJFPC}
{$MODESWITCH ADVANCEDRECORDS}
{$LONGSTRINGS ON}
{$MODESWITCH NESTEDCOMMENTS+}

program unit_test_2_v2_XV;
uses	sysutils
,		strutils
,		strings
,		math
,		Unit_Multi_Int_XV
,		Unit_Multi_UBool
;

{$IFDEF CPU64}
	{$DEFINE 64BIT}
{$ELSE}
	{$IFDEF CPU32}
  		{$DEFINE 32BIT}
	{$ENDIF}
{$ENDIF}

// this must be specified here if the same overide is in Multi_Int unit

const

// You need to comment/uncomment the following lines to specify
// which multi int type you wish to test.
// Only one type can be tested in one instance, but you can
// create multiple executables, one for each type.

{$define Multi_Int_XV}

// You should not need to change anything below this line.

TEST_FAIL_EXPECTED = TRUE;

MULTI_SINGLE_TYPE_MAXVAL	= '340000000000000000000000000000000000000';
// MULTI_REAL_TYPE_MAXVAL		= '99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999';
MULTI_DOUBLE_TYPE_MAXVAL	= '17000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000';

type

{$ifdef Multi_Int_XV}
	big_int	= Multi_Int_XV;
{$else}
	{$fatal These tests only work with Multi_Int_XV}
{$endif}

hex_or_dec	= (bin_str,hex_str,dec_str);

var
T,N,P,R,
MULTI_MAXINT		:big_int;
XV_SIZE,
Multi_Int_NBITS,
start_time,
end_time			:int32;
delta				:double;
got_exception		:boolean;
MULTI_MAXINT_STR,
MULTI_MAXINT_HEX,
MULTI_MAXINT_BIN,
MAXINT_OVER_STR,
MAXINT_OVER_HEX,
MAXINT_OVER_BIN,
NS,RS				:ansistring;


procedure reset_Last_Divisor;
begin
{$ifdef Multi_Int_XV}
	Multi_Int_Reset_XV_Last_Divisor;
{$else}
	{$fatal These tests only work with Multi_Int_XV}
{$endif}
end;


(*---------------------------------*)
// test Pi
(*---------------------------------*)
procedure test_Pi;
{$IFDEF 64BIT}
	const	PRECISION = 10000;
{$ELSE}
	{$IFDEF 32BIT}
		const	PRECISION = 5000;
	{$ENDIF}
{$ENDIF}
var
failed			:T_Multi_UBool;
s				:ansistring;
P1,P2,P3,T,
F,FS,FSC		:big_int;
i				:int32;

	function ArcTanInv(const t: big_int; m,a: UInt64): big_int;
	var	r,s:big_int; b,k:UInt64;
	begin
	s:= t * big_int(m*a);
	b := a*a + 1;
	a := b + b;
	k := 0;
	r := 0;
    repeat
        s:=s div b;
		if s=0 then Break;
		r:=r+s;
		k:=k+2;
		s:=s * big_int(k);
		b:=b+a;
    until FALSE;
    result:=r;
	end;

procedure pi_chudnovsky(var pi:big_int; PRECISION:uint32);
var
c3_over_24,
temp,t		:big_int;
n			:UInt32;

	procedure bs(a : uint32; b : uint32; var pab : big_int; var qab : big_int; var tab_ : big_int);
	var
	m, t, tmp : uint32;
	pam, qam, tam, pmb, qmb, tmb : big_int;

	begin
	if (b - a) = 1 then
		begin
		if a = 0 then
			begin
			pab := 1;
			qab := 1;
			end
		else
			begin
				t:=6*a;
				pab := t-1;
				tmp:=a+a-1;
				pab := pab*big_int(tmp);
				tmp:=t-5;
				pab := pab*big_int(tmp);
				temp := a;
				qab := temp*temp;
				qab := qab*temp;
				qab := qab*c3_over_24;
			end;
		tab_ := 545140134;
		tab_ := tab_*big_int(a);
		tab_ := tab_+13591409;
		tab_ := tab_*pab; // a(a) * p(a)
		if odd(a) then tab_ := tab_*(-1); // = -tab
		end
	else
		begin
		m := (a + b) div 2;
		bs(a, m, pam, qam, tam);
		bs(m, b, pmb, qmb, tmb);
		pab := pam*pmb;
		qab := qam*qmb;
		temp := qmb*tam;
		tab_ := pam*tmb;
		tab_ := tab_+temp;
		end;
	end;

	procedure chudnovsky(var pi : big_int; digits : uint32);
	var
		one_squared, p, q, sqrtc, t : big_int;
		n : uint32;
		digits_per_term : double;
	begin
		digits_per_term := c3_over_24;
		digits_per_term := Ln(digits_per_term/6/2/6)*0.4342944819032518;
		n := round(digits/digits_per_term + 1);
		bs(0, n, p, q, t);
		one_squared := 10;
		one_squared := one_squared**(2*digits);
		sqrtc := one_squared*10005;
		sqrtc := Sqrt(sqrtc);
		pi := sqrtc*big_int(426880);
		pi := pi*q;
		pi := pi div t;
	end;

begin
c3_over_24 := 640320;
temp := c3_over_24*c3_over_24;
c3_over_24 := temp*c3_over_24;
c3_over_24 := c3_over_24 div 24;
chudnovsky(pi, PRECISION);
end;

begin
writeln('--------------------------------');
write('Test Pi: ');

failed:= FALSE;
start_time:= GetTickCount64;

T:= (big_int(10) ** big_int(PRECISION + 4));
P1:= (ArcTanInv(T,48,18)+ArcTanInv(T,32,57)-ArcTanInv(t,20,239)) div 10000;
P2:= (ArcTanInv(T,176,57)+ArcTanInv(T,28,239)-ArcTanInv(T,48,682)+ArcTanInv(T,96,12943)) div 10000;
pi_chudnovsky(P3, PRECISION);

if	(P1 = P2)
and	(P2 = P3)
then writeln('Ok')
else
	begin
	writeln('FAILED!');
	failed:= TRUE;
	writeln('P1=',P1.tostr);
	writeln('P2=',P2.tostr);
	writeln('P3=',P3.tostr);
	end;

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds', [delta]));
end;


(*---------------------------------*)
// test Fact
(*---------------------------------*)
procedure test_Fact;
var
failed			:T_Multi_UBool;
s				:ansistring;
P1,P2,T,
F,FS,FSC		:big_int;
i				:int32;

begin
writeln('--------------------------------');
write('Test Fact: ');

failed:= FALSE;

start_time:= GetTickCount64;

s:='2280058966385387750531712304345336234089351970471019657234227612997853965847635798835992045757082543004651076404429481492735726702338837284359538516468653306625429160207551503354344345787111445922584002';
s+='818116561995980679809308153906676922175433970344674418032486650271905835290848702390148066394087571371381719084083834705143289397377307786595490401129699001354712004975431883261644867724606315936597415';
s+='417281663807090279231267481661350143739752750710878413629789212072422586091871807593802865504322870073895091660224995523763943757312903695257424344652576833807767548298955014117685289979591337921315574';
s+='414385171882147732354691311500466654147313484756817234242663284440669323252177078991951553401499749328119674989816152873493487101340953136158397898370157895394723520831996509093434513075798856068558092';
s+='541830220262707338433662875655428732538862813575073703802844466463096609032494312436330326507729245923667766599375525286845432921620420537820044936663363199059424287956068270893800711294561314155959675';
s+='9088339153782291900491510646687410015510285225141061882566364889308439408424494044324417996846046572131526273';
FSC:= s;
F:=1; for i:=1 to 10000 do F:= (F * big_int(i));
FS:= F; for i:= 1 to 5 do FS:= sqrt(FS);
if (FS = FSC) then writeln('Ok') else begin writeln('FAILED!'); failed:= TRUE; end;

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds', [delta]));

end;


(*---------------------------------*)
// Miller-Rabin prime test
(*---------------------------------*)
Procedure test_Miller_Rabin;
var
s		:ansistring;
failed	:T_Multi_UBool;

	(*------*)
	function powerMod(base, pow, mo: big_int): big_int;
	begin
		result := 1;
		base := base mod mo;
		while pow > 0 do
			begin
			if odd(pow) then
			  result := (result * base) mod mo;
			base := (base * base) mod mo;
			pow := pow shr 1;
			end;
	end;

	(*------*)
	function isComposite(n, base, pow: big_int; s: Integer): Boolean;
	var
	  x: big_int;
	  r: Integer;
	begin
	x := powerMod(base, pow, n);
	if x = 1 then
		exit(False);
	for r := 0 to s - 1 do
		begin
		if x = n - 1 then
			exit(False);
		x := (x * x) mod n;
		end;
	Result := True;
	end;

	(*------*)
	function Miller_Rabin_Deterministic(n: big_int): Boolean;
	var
		bases: array of integer = (2,3,5,7,11,13,17,19,23,29,31,37,41);
		d: big_int;
		s, i: Integer;
	begin
		if (n < 2) then exit(False);
		if (n = 2) or (n = 3) then exit(True);
		if even(n) then exit(False);

		d := n - 1;
		s := 0;
		while (even(d)) do
		begin
		d := d div 2;
		Inc(s);
		end;

		for i := 0 to High(bases) do
		begin
		if bases[i] >= n then continue;
		if isComposite(n, bases[i], d, s) then
		  exit(False);
		end;
		Result := True;
	end;

begin
	writeln('--------------------------------');
	writeln('Test Miller-Rabin');

	failed:= FALSE;

	start_time:= GetTickCount64;

	s:= '111111111111111111157';
	if	Miller_Rabin_Deterministic(s)
	then writeln('Test 1 Ok')
	else begin writeln('Test 1 FAILED!'); failed:= TRUE; end;

	end_time:= GetTickCount64;
	delta:= (end_time - start_time) / 1000;
	writeln(Format('time elapsed is %f seconds', [delta]));

end;



(*---------------------------------*)
BEGIN

{$IFDEF 32BIT}
	XV_SIZE:= 7404;
{$ELSE}
{$IFDEF 64BIT}
	XV_SIZE:= 3702;
{$ENDIF}
{$ENDIF}

Multi_Int_Initialisation(XV_SIZE);

{$ifdef Multi_Int_XV}
	MULTI_MAXINT:= Multi_Int_XV_MAXINT;
	Multi_Int_NBITS:= (XV_SIZE * MULTI_INT_1W_SIZE);
{$else}
	{$fatal These tests only work with Multi_Int_XV}
{$endif}

Multi_Int_RAISE_EXCEPTIONS_ENABLED:= TRUE;

test_Pi;
test_Fact;
test_Miller_Rabin;

writeln('--------------------------------');

END.

