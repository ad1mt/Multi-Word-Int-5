// {$MODE DELPHI}
{$MODESWITCH NESTEDCOMMENTS+}

program speed_test_8_X4;
uses	sysutils
,		strutils
,		strings
,		math
,		Unit_Multi_Int_X4
;

const
MULTI_INT_XV_SIZE	= 32;

M4_SQRT_ITERATIONS	= 50000;
M4_DIV_ITERATIONS	= 500000;
M4_MUL_ITERATIONS	= 10000000;
M4_SUB_ITERATIONS	= 10000000;

var
i,
start_time,
end_time		:int32;
delta			:double;


(********************************)
procedure test_Multi_Int_X4;
var
MV_i,
MV_j,
MV_k	:Multi_Int_X4;

begin

start_time:= GetTickCount64;

MV_i:= Multi_Int_X4_MAXINT;
MV_i:= (MV_i >> 1);
MV_i:= MV_i + 1;

MV_j:= Multi_Int_X4_MAXINT;
MV_j:= (MV_j >> 5);
MV_j:= MV_j - 5;

i:=0;
while (i < (M4_SUB_ITERATIONS div 2)) do
	begin
	MV_k:= MV_i + MV_j;
	Dec(MV_i);
	Dec(MV_j);
	MV_k:= MV_i + MV_j;
	Inc(MV_i);
	Inc(MV_j);

	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of add with %d bit integers', [delta,M4_SUB_ITERATIONS,(Multi_X4_size * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)
start_time:= GetTickCount64;

MV_i:= Multi_Int_X4_MAXINT;
MV_i:= (MV_i >> 1);
MV_i:= MV_i + 1;

MV_j:= Multi_Int_X4_MAXINT;
MV_j:= (MV_j >> 5);
MV_j:= MV_j - 5;

i:=0;
while (i < (M4_SUB_ITERATIONS div 2)) do
	begin
	MV_k:= MV_i - MV_j;
	Dec(MV_i);
	Dec(MV_j);
	MV_k:= MV_i - MV_j;
	Inc(MV_i);
	Inc(MV_j);

	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of subtract with %d bit integers', [delta,M4_SUB_ITERATIONS,(Multi_X4_size * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

MV_i:= Multi_Int_X4_MAXINT;
MV_j:= 4294967296;
MV_i:= MV_i div MV_j;

start_time:= GetTickCount64;

i:=0;
while (i < M4_MUL_ITERATIONS) do
	begin
	MV_k:= MV_i * MV_j;
	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of multiply with %d bit integers', [delta,M4_MUL_ITERATIONS,(Multi_X4_size * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

start_time:= GetTickCount64;

MV_i:= Multi_Int_X4_MAXINT;
MV_j:= 4294967296;

i:=0;
while (i < M4_DIV_ITERATIONS) do
	begin
	MV_k:= MV_i div MV_j;
	Multi_Int_Reset_X4_Last_Divisor;
	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of divide with %d bit integers', [delta,M4_DIV_ITERATIONS,(Multi_X4_size * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

start_time:= GetTickCount64;

MV_i:= Multi_Int_X4_MAXINT;
MV_j:= 4294967296;

i:=0;
while (i < M4_SQRT_ITERATIONS) do
	begin
	MV_k:= sqrt(MV_i);
	Multi_Int_Reset_X4_Last_Divisor;
	Inc(i)
	end;

if	MV_k.overflow
then writeln(' Overflow!');

end_time:= GetTickCount64;
delta:= (end_time - start_time) / 1000;
writeln(Format('time elapsed is %f seconds for %d iterations of sqrt with %d bit integers', [delta,M4_SQRT_ITERATIONS,(MULTI_INT_XV_SIZE * sizeof(MULTI_INT_1W_U) * 8)]));

(*----*)

writeln;
end;


begin
test_Multi_Int_X4;
end.


