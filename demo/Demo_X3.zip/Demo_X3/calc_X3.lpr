{$MODE DELPHI}
{$MODESWITCH NESTEDCOMMENTS+}

program calc_X3;
uses	sysutils
,		strutils
,		strings
,		math
,		Unit_Multi_Int_X3
;

const
operators = ' + - * div (/) mod (%) xor shu shd sqr to-hex from-hex to-bin from-bin pow (^ or **) ';

var
op, biggest	:string;
Mi,
Mj,
Mk			:Multi_Int_X3;
big_size	:int32;

BEGIN
big_size:= Multi_X3_size;
if	(big_size <= 256)
then
	biggest:= Multi_Int_X3_MAXINT.tostr
else
	biggest:= inttostr(trunc(((big_size * MULTI_INT_1W_SIZE)/128000)*38532)) + ' digits long'
;


if (ParamCount = 0) then
	begin
	writeln('calc v',version,' ',big_size,' words (',(big_size * MULTI_INT_1W_SIZE),' bits)');
	writeln('usage: calc  number  operator  number');
	writeln('where: operator can be one of:');
	writeln(operators);
	writeln('where shu/shd means shift bits and sqr means square root');
	writeln('and number can be up to +/- ',biggest);
	end
else
	begin
	if	(ParamStr(2) = 'from-hex')
	then FromHex(ParamStr(1),Mi)
	else if	(ParamStr(2) = 'from-bin')
	then FromBin(ParamStr(1),Mi)
    else Mi:= ParamStr(1);
	Mj:= ParamStr(3);

	if	(not Mi.defined)
	or	(not Mj.defined) then
		begin
		writeln('input number error: maximum is');
		writeln(Multi_Int_X3_MAXINT.tostr);
		end
	else
		begin
		if	(ParamStr(2) = '/')
		or	(ParamStr(2) = 'div')
		then
			begin Mk:= Mi Div Mj; op:= '/'; end
	    else

		if	(ParamStr(2) = 'mod')
		or	(ParamStr(2) = '%')
		then
			begin MK:= Mi Mod Mj; op:= '%'; end

		else if	(ParamStr(2) = 'pow')
		or	(ParamStr(2) = '^')
		or	(ParamStr(2) = '**')
		then
			begin MK:= Mi ** Mj; op:= '^'; end

		else if	(ParamStr(2) = '*') then
			begin MK:= Mi * Mj; op:= '*'; end
	
		else if	(ParamStr(2) = '+') then
			begin MK:= Mi + Mj; op:= '+'; end
	
		else if	(ParamStr(2) = '-') then
			begin MK:= Mi - Mj; op:= '-'; end
	
		else if	(ParamStr(2) = 'xor') then
			begin MK:= Mi Xor Mj; op:= 'XOR'; end

		else if	(ParamStr(2) = 'shu') then
			begin Mk:= (Mi << MULTI_INT_1W_U(Mj)); op:= 'SHU'; end

		else if	(ParamStr(2) = 'shd') then
			begin Mk:= (Mi >> MULTI_INT_1W_U(Mj)); op:= 'SHD'; end

		else if	(ParamStr(2) = 'sqr') then
			begin
			SqRoot(Mi,Mk,Mj);
			op:= 'SQR';
			end

		else if	(ParamStr(2) = 'to-hex') then
			begin
			Mk:= Mi;
			op:= 'HEX';
			end

		else if	(ParamStr(2) = 'to-bin') then
			begin
			Mk:= Mi;
			op:= 'TO-BIN';
			end

		else if	(ParamStr(2) = 'from-hex') then
			begin
			Mk:= Mi;
			op:= 'FROM-HEX';
			end

		else if	(ParamStr(2) = 'from-bin') then
			begin
			Mk:= Mi;
			op:= 'FROM-BIN';
			end

		else
			begin
			writeln('Invalid operator');
			writeln('where: operator can be one of:');
			writeln(operators);
			halt(1);
			end
		;

		if (ParamStr(2) = 'sqr') then
			begin
			writeln;
			writeln(Mk.ToStr);
			writeln('Remainder ',Mj.tostr);
			end
		else if (ParamStr(2) = 'to-hex') then
			begin
			writeln;
			writeln(Mk.ToHex);
			end
		else if (ParamStr(2) = 'to-bin') then
			begin
			writeln;
			writeln(Mk.ToBin);
			end
		else
			begin
			writeln;
			write(Mk.ToStr);
			end;
		if	Mk.overflow
		then writeln(' Overflow!')
		else writeln;
		end;
	end;
END.

